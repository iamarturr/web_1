# web_1

!Для того чтобы протестировать код, необходимо в папке confing/db.php подставить свои данные


[1. Новая версия](https://github.com/iamarturr/web_1/tree/main/new_1)


Первоначальная версия:

![alt tag](https://sun9-21.userapi.com/impf/FA-EHByDGO_akUONJWYKkYKHHxDVaoh-VOSwlw/ExPCwZ5obPw.jpg?size=526x247&quality=96&proxy=1&sign=e45fdc83afdbe09e278122b15fe3beec "Описание будет тут")​

С бд:
![alt tag](https://image.prntscr.com/image/RkqbVx9mT5K4N5jn5dJLKw.png "Описание будет тут")​


С пустой базой:
![alt tag](https://image.prntscr.com/image/Htgl6qnFRd6yOslTHjFuLQ.png "Описание будет тут")​
